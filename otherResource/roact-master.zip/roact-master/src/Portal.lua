local Symbol = require(script.Parent.Symbol)

local Portal = Symbol.named("Portal")

return Portal
